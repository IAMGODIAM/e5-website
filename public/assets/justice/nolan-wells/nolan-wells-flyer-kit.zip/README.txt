Nolan Wells - Accountability Flyer Kit
E5 Enclave Incorporated - e5enclave.com/justice/nolan-wells

23 sheets. Suite I runs in the E5 editorial register (bone paper, oxblood,
redaction bar). Suite II runs in a press register (newsprint, halftone,
overprint). Both carry the same record.

PRINT RESOLUTION
Print sheets are exported at 2x - 200 dpi at 8.5x11 and 11x17, 100 dpi at
24x36. Good for short-run digital and poster printing. For offset or
large-format at 300 dpi, ask and they get re-exported larger.

EVIDENTIARY NOTE
Every claim comes from the grand jury report released publicly by the Jackson
County District Attorney on September 21, 2026, or from the on-record findings
of the Mississippi State Medical Examiner's Office and the independently
retained forensic pathologist. Nothing is alleged. Deliberately absent: any
assertion that audio was altered, any organ-related allegation, and any
implication of named private citizens - each is either contradicted by the
released record or carries defamation exposure.

Verified spine:
- Cause and manner of death undetermined by both the State medical examiner
  and the independently retained forensic pathologist
- Non-fatal injury to the back of the head, found by both, explained by neither
- 132 subpoenas, 43 witnesses, unanimous no true bill
- The publicly released report is redacted; testimony is sealed

USE
Reproduce freely for non-commercial organizing. Do not alter the factual lines.
Post the demand, not a private citizen.

CONTENTS
  Suite I  1a  2400x3600   Forty-three sealed witnesses  ->  flyers/1a-forty-three-sealed-witnesses.png
  Suite I  1b  1700x2628   Undetermined  ->  flyers/1b-undetermined.png
  Suite I  1c  1700x2628   Nobody  ->  flyers/1c-nobody.png
  Suite I  1d  1700x2200   What the county counted  ->  flyers/1d-what-the-county-counted.png
  Suite I  1e  2400x3600   Portrait  ->  flyers/1e-portrait.png
  Suite I  1f  1700x2200   The Record  ->  flyers/1f-the-record.png
  Suite I  1g  1080x1080   No true bill  ->  flyers/1g-no-true-bill.png
  Suite I  1h  1080x1080   Injury to the back of his head  ->  flyers/1h-injury-to-the-back-of-his-head.png
  Suite I  1i  1080x1920   Unseal it  ->  flyers/1i-unseal-it.png
  Suite I  1j  1080x1920   Say how he died  ->  flyers/1j-say-how-he-died.png
  Suite I  1k  1200x630    Grand jury declines  ->  flyers/1k-grand-jury-declines.png
  Suite I  1l  1200x630    No one is accountable  ->  flyers/1l-no-one-is-accountable.png
  Suite II 2a  2400x3600   No one is accountable  ->  flyers/2a-no-one-is-accountable.png
  Suite II 2b  2400x3600   Halftone portrait  ->  flyers/2b-halftone-portrait.png
  Suite II 2c  1700x2628   Records request  ->  flyers/2c-records-request.png
  Suite II 2d  1700x2628   Forty-three tally  ->  flyers/2d-forty-three-tally.png
  Suite II 2e  1700x2200   Tear-off handbill  ->  flyers/2e-tear-off-handbill.png
  Suite II 2f  1700x2200   Typewriter record  ->  flyers/2f-typewriter-record.png
  Suite II 2g  1080x1080   Zero  ->  flyers/2g-zero.png
  Suite II 2h  1080x1080   Halftone face  ->  flyers/2h-halftone-face.png
  Suite II 2i  1080x1920   Open the file  ->  flyers/2i-open-the-file.png
  Suite II 2j  1080x1920   Blue tally  ->  flyers/2j-blue-tally.png
  Suite II 2k  1200x630    Overprint banner  ->  flyers/2k-overprint-banner.png
